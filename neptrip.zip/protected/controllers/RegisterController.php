<?php

class RegisterController extends Controller
{
	public function actionIndex()
	{
		if(isset($_POST['Business'])){
			if($_POST['Business']['image']!=''){
				@copy(Yii::getPathOfAlias('webroot').'/images/temp/business/'.$_POST['Business']['image'], Yii::getPathOfAlias('webroot').'/images/business/'.$_POST['Business']['image']);
				@unlink(Yii::getPathOfAlias('webroot').'/images/temp/business/'.$_POST['Business']['image']);
			}

			$model 				= new Business;
			$model->attributes  = $_POST['Business'];
			$model->save();
			if($model->save()){
				$id 					= $model->id;
				$message            	= new YiiMailMessage;
		        $message->view 			= "register_email";
		        $params              	= array('myMail'=>Business::model()->findByPk($id));
		        $message->subject    	= 'User registered action required';
		        $message->setBody($params, 'text/html');                
		        $message->addTo(Yii::app()->params['adminEmail']);
		        $message->from = 'noreply@neptrip.com';   
		        //echo '<pre>';print_r($message->body);exit;
		        Yii::app()->mail->send($message);

				Yii::app()->user->setFlash('success', "User registered sucessfully!");
				$this->redirect('register');
			}
		}

		$this->render('index',array(
				'model'			=> new Business('register'),
				'businesstypes'	=> CHtml::listData(Businesstypes::model()->findAll(), 'type', 'type'),
				'zones'			=> CHtml::listData(Zones::model()->findAll(), 'zone', 'zone'),
				'districts' 	=> CHtml::listData(Districts::model()->findAll(), 'district', 'district')
		));
	}

}