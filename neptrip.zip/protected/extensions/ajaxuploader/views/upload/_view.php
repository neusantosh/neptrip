<?
  /*
  * this is my output, you can modify it or use the next the one commented with gives the two images
  */
?>

<img  src="<?php echo '../'.$source.$resized; ?>" width="220" height="220" alt="my image"/>

<?php
	/*
	* this is the output from the original source
	* http://www.sanwebe.com/2012/05/ajax-image-upload-and-resize-with-jquery-and-php/comment-page-2#comment-5624
	*/
	
	/*
	<table width="100%" border="0" cellpadding="4" cellspacing="0">
		<tr>
		<td align="center"><img src="<?php echo '../'.$source.$resized; ?>" alt="Thumbnail"></td>
		</tr><tr>
		<td align="center"><img src="<?php echo '../'.$source.$original; ?>" alt="Resized Image"></td>
	   </tr>
	</table>
   */
	
?>