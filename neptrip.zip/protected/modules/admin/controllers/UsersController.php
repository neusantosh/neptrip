<?php 
 class UsersController extends Controller{

 	public $layout = 'admin';

 	public function actionIndex(){
 		$model = new Business; 		
 		$this->render('index',array('model'=>$model));
 	}

 	public function actionView($id){
 		$data = Business::model()->findByPk($id);
 		$this->render('view',array('data'=>$data));
 	}


 	public function actionDelete($id){
 		Business::model()->deleteByPk($id);
 		 Yii::app()->user->setFlash('success','User Deleted Successfully.');
 	}

 	public function actionUpdate($id){
 		if(isset($_POST["Business"])){
 			if($_POST['Business']['image']!=''){
 				$criteria = new CDbCriteria();
		 		$criteria->select = 'image';
		 		$criteria->condition = 'id='.$id;
		 		$userimage = Business::model()->find($criteria);
		 		if($userimage['image']!=''){
		 			@unlink(Yii::getPathOfAlias('webroot').'/images/temp/business/'.$userimage['image']); //removes the old image
		 			@copy(Yii::getPathOfAlias('webroot').'/images/temp/business/'.$_POST['Business']['image'], Yii::getPathOfAlias('webroot').'/images/business/'.$_POST['Business']['image']); //copies the new image from temp folder to mainfolder
					@unlink(Yii::getPathOfAlias('webroot').'/images/temp/business/'.$_POST['Business']['image']); //removes the temp image
		 		}
 			}
 			$model = Business::model()->findByPk($id);
 			if($model->validate()){
 				 $model->setAttributes($_POST['Business']);
 				 if ($model->save()) {
 				 	Yii::app()->user->setFlash('success','User Updated Successfully.');
                	$this->redirect(array('users/index'));
            	}
 			}else{
 				$errores = $model->getErrors();
 				echo '<pre>';print_r($errores);exit;
 			}
 		}

 		$this->render('update', array(
	 			'model'			=> new Business('update'),
	 			'userdetails'	=> Business::model()->findByPk($id),
	 			'businesstypes'	=> CHtml::listData(Businesstypes::model()->findAll(), 'type', 'type'),
				'zones'			=> CHtml::listData(Zones::model()->findAll(), 'zone', 'zone'),
				'districts' 	=> CHtml::listData(Districts::model()->findAll(), 'district', 'district')
 			));
 	}

 	public function actionCreateUserPassword($id){
 		if(isset($_POST['Business'])){
 			$model = Business::model()->findByPk($id);
 			if($model->validate()){
 				$model->username = $_POST['Business']['username'];
 				$model->password = sha1($_POST['Business']['password']);
 				$model->orginal_password = $_POST['Business']['password'];
 				$model->update();
 				Yii::app()->user->setFlash('success','Username and password updated successfully.');
 				$this->redirect(array('users/index'));
 			}
 		}
	 		$criteria = new CDbCriteria();
			$criteria->select = "username,orginal_password";
			$criteria->condition = "id=$id";
			$userdetails = Business::model()->findAll($criteria);

 			$this->render('createuserpass', array('userdetails'=>$userdetails));
 	}

 	public function actionCreatePassword(){
 			$alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
		    $pass = array(); //remember to declare $pass as an array
		    $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
		    for ($i = 0; $i < 8; $i++) {
		        $n = rand(0, $alphaLength);
		        $pass[] = $alphabet[$n];
		    }
		    echo implode($pass); //turn the array into a string
 	}

 	public function actionApprove($id){
 		$model = Business::model()->findByPk($id);
 		$model->status = 1;
 		$model->update();
 		Yii::app()->user->setFlash('success','User approved successfully.');
 		$this->redirect(array('users/index'));
 	}

 	public function actionReject($id){
 		$model = Business::model()->findByPk($id);
 		$model->status = 2;
 		$model->update();
 		Yii::app()->user->setFlash('success','User rejected successfully.');
 		$this->redirect(array('users/index'));
 	}

 	public function actionUpload(){
            $tempFolder=Yii::getPathOfAlias('webroot').'/images/temp/business/';

            if(!file_exists($tempFolder) && !is_dir($tempFolder)) mkdir($tempFolder, 0777, TRUE);
			//if(!file_exists($tempFolder.'/chunks') && !is_dir($tempFolder.'/chunks')) mkdir($tempFolder.'/chunks', 0777, TRUE);

            Yii::import("ext.EFineUploader.qqFileUploader");

            $uploader = new qqFileUploader();
            $uploader->allowedExtensions = array('jpg','jpeg');
            $uploader->sizeLimit = 2 * 1024 * 1024;//maximum file size in bytes
            //$uploader->chunksFolder = $tempFolder.'chunks';

            $result = $uploader->handleUpload($tempFolder);
            $result['filename'] = $uploader->getUploadName();
            //$result['folder'] = $webFolder;

            $uploadedFile=$tempFolder.$result['filename'];

            header("Content-Type: text/plain");
            $result=htmlspecialchars(json_encode($result), ENT_NOQUOTES);
            echo $result;
            Yii::app()->end();
    }

 }