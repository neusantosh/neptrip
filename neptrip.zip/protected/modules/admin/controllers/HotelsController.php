<?php 
class HotelsController extends Controller{

	public $layout = 'admin';

	public function actionIndex(){
		echo '<pre>';print_r(Hotels::model()->findAll());exit;
		$this->render('index',array(
			'records'  => Hotels::model()->findAll()
		));
	}
}