<?php 

class ResturantsController extends Controller{
	
	public $layout = 'admin';

	public function actionIndex(){

		$criteria = new CDbCriteria;
            $total = Resturants::model()->count();
 
            $pages = new CPagination($total);
            $pages->pageSize = Yii::app()->params['itemsperpage'];
            $pages->applyLimit($criteria);
 
            $resturants = Resturants::model()->findAll($criteria);

		$this->render('index', array(
			'resturants' => $resturants,
             'pages' 	=> $pages,
		));
	}


	public function actionView($id=null){
		$this->render('view',array(
			'data' => Resturants::model()->findByPk($id)
		));
	}
}