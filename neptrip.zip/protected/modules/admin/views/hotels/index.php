<?php
	echo 'Hotel Admin';
?>