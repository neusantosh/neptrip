<?php $this->renderPartial('application.views.partials.admin_menu',false);?>

<?php $this->beginWidget('bootstrap.widgets.TbHeroUnit', array(
    'heading'=>'Neptrip',
)); ?>
 
    <p>
    	Welcome to Neptrip Dashboard.
    </p>
    
 
<?php $this->endWidget(); ?>