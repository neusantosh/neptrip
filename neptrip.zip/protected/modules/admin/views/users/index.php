<fieldset style="margin-top:40px;">
    <legend>Users</legend>
<?php if(Yii::app()->user->hasFlash('success')):?>
    <div class="info">
        <?php echo Yii::app()->user->getFlash('success'); ?>
    </div>
<?php endif; ?>
    <?php 
    $this->widget('bootstrap.widgets.TbGridView', array(
       'dataProvider' => $model->search(),
       'type'=>'striped bordered condensed',
       'filter' => $model,
       'template' => "{items}\n{pager}",
       'ajaxUpdate'=>true,
       'columns' => array(
            array(
                'name' => 'business_name',
                'header' => 'Business Name',
            ),
            array(
                'name' => 'business_type',
                'header' => 'Business Type',
            ),

            array(
                'name' => 'status',
                'header' => 'Status',
                'value' => 'getStatusName($data->status)'
            ),

            array(
                'name' => 'city',
                'header' => 'City',
            ),
            array(
                        'class'=>'bootstrap.widgets.TbButtonColumn',
                        'header'  => 'Options',
                        'template'=>'{view}{update}{delete}{updateuserpass}{approve}{reject}',
                        'htmlOptions' => array('width'=>'200'),
                        'buttons'=>array(
                                'view' => array(
                                  'url'=>'Yii::app()->controller->createUrl("users/view/id/".$data->id)',
                                ),
                                'update' => array(
                                  'url'=>'Yii::app()->controller->createUrl("users/update/id/".$data->id)',
                                ),
                                'delete' => array(
                                  'url'=>'Yii::app()->controller->createUrl("users/delete/id/".$data->id)',
                                ),
                                'updateuserpass' => array(
                                  'icon'=>'gear',
                                  'url'=>'Yii::app()->controller->createUrl("users/createuserpassword/id/".$data->id)',  
                                ),
                                'approve' => array(
                                  'icon'=>'check',
                                  'url'=>'Yii::app()->controller->createUrl("users/approve/id/".$data->id)',
                                  'onclick' =>'Are you sure to appove this user?'
                                ),
                                'reject' => array(
                                  'icon'=>'minus',
                                  'url'=>'Yii::app()->controller->createUrl("users/reject/id/".$data->id)',
                                  'onclick' => 'return confirm(Are you sure to reject this user?)'
                                ),
                        ),
                ),
        ),
    )); ?>
  </fieldset>

  <?php 
  function getStatusName($status){
  if($status == 0)
    return 'Not Approved';
  if($status == 1)
    return 'Approved';
  if($status == 2)
    return "Rejected";
}
  ?>